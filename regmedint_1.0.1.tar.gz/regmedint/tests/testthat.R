library(testthat)
library(regmedint)

test_check("regmedint")
